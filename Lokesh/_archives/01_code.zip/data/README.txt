Generate with: python -m datasets.synthetic --out data/synthetic --n 24 --seed 0
