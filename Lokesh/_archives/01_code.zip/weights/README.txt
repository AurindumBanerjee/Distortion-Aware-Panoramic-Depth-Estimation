Download MiDaS weights here (see README §5); DAP weights go in weights/dap/.
